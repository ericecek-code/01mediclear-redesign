import { useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, X, Camera, Image as ImageIcon } from 'lucide-react';
import type { AppMode } from '../types';

interface ImageUploadProps {
  mode: AppMode;
  imagePreview: string | null;
  isAnalyzing: boolean;
  onImageSelect: (file: File) => void;
  onClear: () => void;
  onAnalyze: () => void;
  hasApiKey: boolean;
}

export default function ImageUpload({
  mode,
  imagePreview,
  isAnalyzing,
  onImageSelect,
  onClear,
  onAnalyze,
  hasApiKey,
}: ImageUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      const file = e.dataTransfer.files[0];
      if (file && file.type.startsWith('image/')) {
        onImageSelect(file);
      }
    },
    [onImageSelect]
  );

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
  }, []);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-white/80 uppercase tracking-wider flex items-center gap-2">
          <ImageIcon className="h-4 w-4" />
          {mode === 'dental' ? 'Dental X-Ray' : 'Medical X-Ray'}
        </h2>
        {imagePreview && (
          <button
            onClick={onClear}
            className="flex items-center gap-1 text-xs text-white/40 hover:text-red-400 transition-colors"
          >
            <X className="h-3 w-3" /> Clear
          </button>
        )}
      </div>

      <AnimatePresence mode="wait">
        {!imagePreview ? (
          <motion.div
            key="upload"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onClick={() => fileInputRef.current?.click()}
            className={`group cursor-pointer rounded-2xl border-2 border-dashed transition-all duration-300 ${
              mode === 'dental'
                ? 'border-teal-500/30 hover:border-teal-400/60 hover:bg-teal-500/5'
                : 'border-blue-500/30 hover:border-blue-400/60 hover:bg-blue-500/5'
            } p-8 sm:p-12 text-center`}
          >
            <div className={`mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl ${
              mode === 'dental' ? 'bg-teal-500/10' : 'bg-blue-500/10'
            } transition-colors group-hover:scale-110 duration-300`}>
              <Upload className={`h-7 w-7 ${
                mode === 'dental' ? 'text-teal-400' : 'text-blue-400'
              }`} />
            </div>
            <p className="text-sm font-medium text-white/70">
              Drop your X-ray image here
            </p>
            <p className="mt-1 text-xs text-white/40">
              or click to browse • JPEG, PNG supported
            </p>
            <div className="mt-4 flex items-center justify-center gap-3">
              <span className={`inline-flex items-center gap-1 rounded-full px-3 py-1 text-[10px] font-medium ${
                mode === 'dental' ? 'bg-teal-500/10 text-teal-400' : 'bg-blue-500/10 text-blue-400'
              }`}>
                <Camera className="h-3 w-3" />
                {mode === 'dental' ? 'OPG • Periapical • Bitewing' : 'Chest • Bone • Spine'}
              </span>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="preview"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="space-y-3"
          >
            <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-black/50">
              <img
                src={imagePreview}
                alt="X-ray preview"
                className="w-full h-auto max-h-[400px] object-contain"
              />
              {isAnalyzing && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm">
                  <div className="text-center">
                    <div className={`mx-auto mb-3 h-12 w-12 animate-spin rounded-full border-3 border-transparent ${
                      mode === 'dental' ? 'border-t-teal-400' : 'border-t-blue-400'
                    }`} />
                    <p className="text-sm font-medium text-white">Analyzing with Gemini AI...</p>
                    <p className="text-xs text-white/50 mt-1">This may take a few seconds</p>
                  </div>
                </div>
              )}
            </div>

            <button
              onClick={onAnalyze}
              disabled={isAnalyzing || !hasApiKey}
              className={`w-full rounded-xl py-3 px-4 text-sm font-semibold text-white transition-all duration-300 disabled:opacity-40 disabled:cursor-not-allowed ${
                mode === 'dental'
                  ? 'bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-500 hover:to-cyan-500 shadow-lg shadow-teal-600/20'
                  : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 shadow-lg shadow-blue-600/20'
              } ${isAnalyzing ? 'animate-pulse' : ''}`}
            >
              {isAnalyzing ? 'Analyzing...' : !hasApiKey ? 'Enter API Key First' : `Analyze ${mode === 'dental' ? 'Dental' : 'Medical'} X-Ray`}
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onImageSelect(file);
        }}
        className="hidden"
      />
    </div>
  );
}
