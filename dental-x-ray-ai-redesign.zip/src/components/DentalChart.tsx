import { motion } from 'framer-motion';
import { FDI_TEETH, TOOTH_NAMES, DENTAL_CONDITION_COLORS } from '../types';
import type { ToothFinding } from '../types';

interface DentalChartProps {
  findings: ToothFinding[];
  selectedTooth: number | null;
  onSelectTooth: (tooth: number | null) => void;
}

function ToothIcon({ fdi, status, isSelected, onClick }: {
  fdi: number;
  status: string;
  isSelected: boolean;
  onClick: () => void;
}) {
  const color = DENTAL_CONDITION_COLORS[status] || DENTAL_CONDITION_COLORS.healthy;
  const isUpper = fdi < 30;

  return (
    <motion.button
      onClick={onClick}
      whileHover={{ scale: 1.15 }}
      whileTap={{ scale: 0.95 }}
      className={`relative flex flex-col items-center gap-0.5 p-1 rounded-lg transition-all ${
        isSelected ? 'bg-white/10 ring-1 ring-white/30' : 'hover:bg-white/5'
      }`}
    >
      <span className={`text-[9px] font-mono font-bold ${isUpper ? 'order-2' : 'order-first'}`}
        style={{ color: color + 'CC' }}>
        {fdi}
      </span>
      <svg
        width="20"
        height="28"
        viewBox="0 0 20 28"
        className={`${isUpper ? 'order-first' : 'order-2'} ${!isUpper ? 'rotate-180' : ''}`}
      >
        {/* Tooth shape */}
        <path
          d="M10 2C7 2 5 4.5 5 7c0 2 0.5 3.5 1.2 5.5C7 15 8 19 8.5 22c0.3 2 0.7 4 1.5 4s1.2-2 1.5-4c0.5-3 1.5-7 2.3-9.5C14.5 10.5 15 9 15 7c0-2.5-2-5-5-5z"
          fill={status === 'missing' ? 'transparent' : color + '30'}
          stroke={color}
          strokeWidth="1.5"
          strokeDasharray={status === 'missing' ? '2,2' : 'none'}
        />
        {/* Condition indicator */}
        {status === 'caries' && (
          <circle cx="10" cy="8" r="3" fill={color} opacity="0.6" />
        )}
        {status === 'restored' && (
          <rect x="7" y="5" width="6" height="5" rx="1" fill={color} opacity="0.5" />
        )}
        {status === 'crown' && (
          <path d="M6 4 L10 2 L14 4 L14 8 L6 8Z" fill={color} opacity="0.5" />
        )}
        {status === 'root_canal' && (
          <line x1="10" y1="10" x2="10" y2="22" stroke={color} strokeWidth="1.5" opacity="0.6" />
        )}
        {status === 'implant' && (
          <>
            <line x1="10" y1="10" x2="10" y2="24" stroke={color} strokeWidth="2" />
            <line x1="7" y1="14" x2="13" y2="14" stroke={color} strokeWidth="1" />
            <line x1="7" y1="18" x2="13" y2="18" stroke={color} strokeWidth="1" />
          </>
        )}
      </svg>
    </motion.button>
  );
}

export default function DentalChart({ findings, selectedTooth, onSelectTooth }: DentalChartProps) {
  const findingsMap = new Map(findings.map(f => [f.fdi_number, f]));

  const getStatus = (fdi: number) => {
    return findingsMap.get(fdi)?.status || 'healthy';
  };

  const selectedFinding = selectedTooth ? findingsMap.get(selectedTooth) : null;

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-semibold text-white/80 uppercase tracking-wider flex items-center gap-2">
        <svg className="h-4 w-4 text-teal-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M12 2C8 2 6 5 6 8c0 3 1 5 2 8 1 3 2 6 4 6s3-3 4-6c1-3 2-5 2-8 0-3-2-6-6-6z" />
        </svg>
        Dental Chart (FDI)
      </h3>

      <div className="rounded-2xl border border-white/10 bg-black/30 p-4 backdrop-blur-sm">
        {/* Upper Jaw */}
        <div className="mb-1">
          <div className="flex items-center justify-center gap-0.5 text-[9px] text-white/30 mb-1">
            <span>Q1 (Upper Right)</span>
            <span className="mx-4">|</span>
            <span>Q2 (Upper Left)</span>
          </div>
          <div className="flex items-center justify-center">
            <div className="flex gap-0.5">
              {FDI_TEETH.upper_right.map(fdi => (
                <ToothIcon
                  key={fdi}
                  fdi={fdi}
                  status={getStatus(fdi)}
                  isSelected={selectedTooth === fdi}
                  onClick={() => onSelectTooth(selectedTooth === fdi ? null : fdi)}
                />
              ))}
            </div>
            <div className="mx-1 h-8 w-px bg-white/20" />
            <div className="flex gap-0.5">
              {FDI_TEETH.upper_left.map(fdi => (
                <ToothIcon
                  key={fdi}
                  fdi={fdi}
                  status={getStatus(fdi)}
                  isSelected={selectedTooth === fdi}
                  onClick={() => onSelectTooth(selectedTooth === fdi ? null : fdi)}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="my-2 border-t border-dashed border-white/10" />

        {/* Lower Jaw */}
        <div className="mt-1">
          <div className="flex items-center justify-center">
            <div className="flex gap-0.5">
              {FDI_TEETH.lower_right.map(fdi => (
                <ToothIcon
                  key={fdi}
                  fdi={fdi}
                  status={getStatus(fdi)}
                  isSelected={selectedTooth === fdi}
                  onClick={() => onSelectTooth(selectedTooth === fdi ? null : fdi)}
                />
              ))}
            </div>
            <div className="mx-1 h-8 w-px bg-white/20" />
            <div className="flex gap-0.5">
              {FDI_TEETH.lower_left.map(fdi => (
                <ToothIcon
                  key={fdi}
                  fdi={fdi}
                  status={getStatus(fdi)}
                  isSelected={selectedTooth === fdi}
                  onClick={() => onSelectTooth(selectedTooth === fdi ? null : fdi)}
                />
              ))}
            </div>
          </div>
          <div className="flex items-center justify-center gap-0.5 text-[9px] text-white/30 mt-1">
            <span>Q4 (Lower Right)</span>
            <span className="mx-4">|</span>
            <span>Q3 (Lower Left)</span>
          </div>
        </div>

        {/* Selected tooth detail */}
        {selectedTooth && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-4 rounded-xl border border-teal-500/20 bg-teal-500/5 p-3"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold text-teal-300">
                Tooth #{selectedTooth}
              </span>
              <span className="text-xs text-white/50">
                {TOOTH_NAMES[selectedTooth] || 'Unknown'}
              </span>
            </div>
            {selectedFinding ? (
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full" style={{ backgroundColor: DENTAL_CONDITION_COLORS[selectedFinding.status] }} />
                  <span className="text-xs text-white/70 capitalize">{selectedFinding.status.replace('_', ' ')}</span>
                  <span className="text-[10px] text-white/40">
                    ({Math.round(selectedFinding.confidence * 100)}% confidence)
                  </span>
                </div>
                {selectedFinding.findings.map((f, i) => (
                  <p key={i} className="text-xs text-white/50 pl-4">• {f}</p>
                ))}
              </div>
            ) : (
              <p className="text-xs text-white/40">No findings — appears healthy</p>
            )}
          </motion.div>
        )}
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-2">
        {Object.entries(DENTAL_CONDITION_COLORS).map(([key, color]) => (
          <div key={key} className="flex items-center gap-1.5">
            <div className="h-2 w-2 rounded-full" style={{ backgroundColor: color }} />
            <span className="text-[10px] text-white/40 capitalize">{key.replace('_', ' ')}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
