import { useState } from 'react';
import { Key, Eye, EyeOff, ExternalLink } from 'lucide-react';

interface ApiKeyInputProps {
  apiKey: string;
  onApiKeyChange: (key: string) => void;
}

export default function ApiKeyInput({ apiKey, onApiKeyChange }: ApiKeyInputProps) {
  const [showKey, setShowKey] = useState(false);
  const [isExpanded, setIsExpanded] = useState(!apiKey);

  if (!isExpanded && apiKey) {
    return (
      <button
        onClick={() => setIsExpanded(true)}
        className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs text-white/50 hover:bg-white/10 transition-colors"
      >
        <Key className="h-3.5 w-3.5 text-green-400" />
        <span>API Key configured</span>
        <span className="text-white/30">•••••{apiKey.slice(-4)}</span>
      </button>
    );
  }

  return (
    <div className="rounded-xl border border-white/10 bg-white/5 p-4 backdrop-blur-sm">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Key className="h-4 w-4 text-amber-400" />
          <h3 className="text-sm font-medium text-white">Gemini API Key</h3>
        </div>
        <a
          href="https://aistudio.google.com/apikey"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1 text-xs text-blue-400 hover:text-blue-300 transition-colors"
        >
          Get free key <ExternalLink className="h-3 w-3" />
        </a>
      </div>
      <div className="relative">
        <input
          type={showKey ? 'text' : 'password'}
          value={apiKey}
          onChange={(e) => onApiKeyChange(e.target.value)}
          placeholder="Enter your Gemini API key..."
          className="w-full rounded-lg border border-white/10 bg-black/30 px-3 py-2.5 pr-10 text-sm text-white placeholder-white/30 focus:border-blue-500/50 focus:outline-none focus:ring-1 focus:ring-blue-500/30 transition-all"
        />
        <button
          onClick={() => setShowKey(!showKey)}
          className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-white/30 hover:text-white/60 transition-colors"
        >
          {showKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </button>
      </div>
      {apiKey && (
        <button
          onClick={() => setIsExpanded(false)}
          className="mt-2 text-xs text-white/40 hover:text-white/60 transition-colors"
        >
          Minimize
        </button>
      )}
      <p className="mt-2 text-[10px] text-white/30">
        Your key is stored only in your browser session. Never shared or saved externally.
      </p>
    </div>
  );
}
