import { motion } from 'framer-motion';
import { Stethoscope, Activity } from 'lucide-react';
import type { AppMode } from '../types';

interface HeaderProps {
  mode: AppMode;
  onModeChange: (mode: AppMode) => void;
}

export default function Header({ mode, onModeChange }: HeaderProps) {
  return (
    <header className="relative z-10 border-b border-white/10 bg-black/30 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        <div className="flex items-center gap-3">
          <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${
            mode === 'dental' 
              ? 'bg-gradient-to-br from-teal-500 to-cyan-600' 
              : 'bg-gradient-to-br from-blue-500 to-indigo-600'
          } shadow-lg`}>
            <Activity className="h-5 w-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white tracking-tight">
              Medi<span className={mode === 'dental' ? 'text-teal-400' : 'text-blue-400'}>Clear</span>
              <span className="ml-1 text-xs font-medium text-white/50">AI</span>
            </h1>
            <p className="text-[10px] text-white/40 uppercase tracking-widest">
              {mode === 'dental' ? 'Dental X-Ray Intelligence' : 'Medical X-Ray Intelligence'}
            </p>
          </div>
        </div>

        {/* Mode Switcher */}
        <div className="relative flex rounded-xl bg-white/5 p-1 border border-white/10">
          <motion.div
            className={`absolute top-1 bottom-1 rounded-lg ${
              mode === 'medical' 
                ? 'bg-gradient-to-r from-blue-600 to-indigo-600' 
                : 'bg-gradient-to-r from-teal-600 to-cyan-600'
            }`}
            layout
            style={{
              left: mode === 'medical' ? '4px' : '50%',
              right: mode === 'dental' ? '4px' : '50%',
            }}
            transition={{ type: 'spring', stiffness: 500, damping: 35 }}
          />
          <button
            onClick={() => onModeChange('medical')}
            className={`relative z-10 flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${
              mode === 'medical' ? 'text-white' : 'text-white/50 hover:text-white/70'
            }`}
          >
            <Stethoscope className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Medical</span>
          </button>
          <button
            onClick={() => onModeChange('dental')}
            className={`relative z-10 flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${
              mode === 'dental' ? 'text-white' : 'text-white/50 hover:text-white/70'
            }`}
          >
            <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 2C8 2 6 5 6 8c0 3 1 5 2 8 1 3 2 6 4 6s3-3 4-6c1-3 2-5 2-8 0-3-2-6-6-6z" />
            </svg>
            <span className="hidden sm:inline">Dental</span>
          </button>
        </div>
      </div>
    </header>
  );
}
