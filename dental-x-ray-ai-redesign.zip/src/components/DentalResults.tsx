import { motion } from 'framer-motion';
import { AlertTriangle, CheckCircle, FileText, TrendingUp } from 'lucide-react';
import type { DentalAnalysisResult } from '../types';
import { DENTAL_CONDITION_COLORS } from '../types';

interface DentalResultsProps {
  result: DentalAnalysisResult;
}

export default function DentalResults({ result }: DentalResultsProps) {
  const totalTeeth = result.teeth_identified.length;
  const healthyTeeth = result.teeth_identified.filter(t => t.status === 'healthy').length;
  const problemTeeth = totalTeeth - healthyTeeth;
  const healthScore = totalTeeth > 0 ? Math.round((healthyTeeth / totalTeeth) * 100) : 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      {/* Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="rounded-xl border border-teal-500/20 bg-teal-500/5 p-3">
          <p className="text-[10px] text-teal-300/60 uppercase tracking-wider">Health Score</p>
          <p className="text-2xl font-bold text-teal-300 mt-1">{healthScore}%</p>
        </div>
        <div className="rounded-xl border border-white/10 bg-white/5 p-3">
          <p className="text-[10px] text-white/40 uppercase tracking-wider">Teeth Found</p>
          <p className="text-2xl font-bold text-white/80 mt-1">{totalTeeth}</p>
        </div>
        <div className="rounded-xl border border-green-500/20 bg-green-500/5 p-3">
          <p className="text-[10px] text-green-300/60 uppercase tracking-wider">Healthy</p>
          <p className="text-2xl font-bold text-green-300 mt-1">{healthyTeeth}</p>
        </div>
        <div className="rounded-xl border border-red-500/20 bg-red-500/5 p-3">
          <p className="text-[10px] text-red-300/60 uppercase tracking-wider">Findings</p>
          <p className="text-2xl font-bold text-red-300 mt-1">{problemTeeth}</p>
        </div>
      </div>

      {/* Image Type & Quality */}
      <div className="flex gap-2">
        <span className="inline-flex items-center gap-1 rounded-full bg-teal-500/10 px-3 py-1 text-xs text-teal-300">
          <FileText className="h-3 w-3" />
          {result.image_type}
        </span>
        <span className={`inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs ${
          result.quality === 'good' ? 'bg-green-500/10 text-green-300' :
          result.quality === 'acceptable' ? 'bg-yellow-500/10 text-yellow-300' :
          'bg-red-500/10 text-red-300'
        }`}>
          <TrendingUp className="h-3 w-3" />
          Quality: {result.quality}
        </span>
      </div>

      {/* Pathologies */}
      {result.pathologies.length > 0 && (
        <div className="space-y-2">
          <h3 className="text-sm font-semibold text-white/80 flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-400" />
            Pathological Findings
          </h3>
          <div className="space-y-2">
            {result.pathologies.map((p, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                className="rounded-xl border border-white/10 bg-white/5 p-3"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div
                      className="h-3 w-3 rounded-full flex-shrink-0"
                      style={{ backgroundColor: DENTAL_CONDITION_COLORS[p.type] || '#FF6B6B' }}
                    />
                    <span className="text-sm font-medium text-white/80 capitalize">
                      {p.type.replace('_', ' ')}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                      p.severity === 'severe' ? 'bg-red-500/20 text-red-300' :
                      p.severity === 'moderate' ? 'bg-amber-500/20 text-amber-300' :
                      'bg-yellow-500/20 text-yellow-300'
                    }`}>
                      {p.severity}
                    </span>
                    <span className="text-[10px] text-white/30">
                      {Math.round(p.confidence * 100)}%
                    </span>
                  </div>
                </div>
                <p className="mt-1 text-xs text-white/50">{p.location}</p>
                <p className="mt-1 text-xs text-white/40">{p.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* Overall Assessment */}
      <div className="rounded-xl border border-teal-500/20 bg-teal-500/5 p-4">
        <h3 className="text-sm font-semibold text-teal-300 flex items-center gap-2 mb-2">
          <CheckCircle className="h-4 w-4" />
          Overall Assessment
        </h3>
        <p className="text-sm text-white/70 leading-relaxed">{result.overall_assessment}</p>
      </div>

      {/* Recommendations */}
      {result.recommendations.length > 0 && (
        <div className="rounded-xl border border-white/10 bg-white/5 p-4">
          <h3 className="text-sm font-semibold text-white/80 mb-2">Recommendations</h3>
          <ul className="space-y-1">
            {result.recommendations.map((r, i) => (
              <li key={i} className="flex items-start gap-2 text-xs text-white/60">
                <span className="text-teal-400 mt-0.5">→</span>
                {r}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Disclaimer */}
      <div className="rounded-lg border border-amber-500/10 bg-amber-500/5 p-3">
        <p className="text-[10px] text-amber-300/60 leading-relaxed">
          ⚠️ <strong>Disclaimer:</strong> This AI analysis is for informational purposes only and is not a medical diagnosis.
          All findings must be verified by a qualified dental professional. MediClear AI is a diagnostic support tool, not a replacement for professional clinical judgment.
        </p>
      </div>
    </motion.div>
  );
}
