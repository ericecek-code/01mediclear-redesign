import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  FileJson,
  ChevronDown,
  ChevronRight,
  Layers,
  Smartphone,
  Cloud,
  Shield,
  Cpu,
  Palette,
  Calendar,
  GitBranch,
} from 'lucide-react';

interface ProposalViewProps {
  proposal: any;
}

function Section({ title, icon: Icon, children, defaultOpen = false }: {
  title: string;
  icon: React.ElementType;
  children: React.ReactNode;
  defaultOpen?: boolean;
}) {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="rounded-xl border border-white/10 bg-white/5 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center gap-3 p-4 text-left hover:bg-white/5 transition-colors"
      >
        <Icon className="h-5 w-5 text-blue-400 flex-shrink-0" />
        <span className="text-sm font-semibold text-white flex-1">{title}</span>
        {isOpen ? (
          <ChevronDown className="h-4 w-4 text-white/40" />
        ) : (
          <ChevronRight className="h-4 w-4 text-white/40" />
        )}
      </button>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="px-4 pb-4 border-t border-white/5"
        >
          {children}
        </motion.div>
      )}
    </div>
  );
}

export default function ProposalView({ proposal }: ProposalViewProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      {/* Project Header */}
      <div className="rounded-2xl border border-blue-500/20 bg-gradient-to-br from-blue-500/10 to-indigo-500/10 p-6">
        <div className="flex items-start gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 shadow-lg">
            <FileJson className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">{proposal.project.name}</h2>
            <p className="text-sm text-blue-300/70 mt-1">{proposal.project.tagline}</p>
            <p className="text-xs text-white/40 mt-2">v{proposal.project.version}</p>
          </div>
        </div>
        <p className="mt-4 text-sm text-white/60 leading-relaxed">{proposal.project.description}</p>
      </div>

      {/* Modules */}
      <Section title="Architecture — Dual Module System" icon={Layers} defaultOpen={true}>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          {proposal.architecture.modules.map((mod: any) => (
            <div
              key={mod.id}
              className="rounded-xl border border-white/10 p-4"
              style={{ borderColor: mod.color_scheme.primary + '30' }}
            >
              <h4 className="text-sm font-semibold" style={{ color: mod.color_scheme.primary }}>
                {mod.name}
              </h4>
              <p className="text-xs text-white/40 mt-1">{mod.description}</p>
              <ul className="mt-3 space-y-1">
                {mod.features.slice(0, 5).map((f: string, i: number) => (
                  <li key={i} className="text-[11px] text-white/50 flex items-start gap-1.5">
                    <span style={{ color: mod.color_scheme.accent }}>▸</span>
                    {f}
                  </li>
                ))}
                {mod.features.length > 5 && (
                  <li className="text-[10px] text-white/30">+{mod.features.length - 5} more features</li>
                )}
              </ul>
            </div>
          ))}
        </div>
      </Section>

      {/* Dental Standards */}
      <Section title="Dental Standards (FDI / WHO)" icon={Shield}>
        <div className="mt-3 space-y-3">
          <div className="rounded-lg bg-black/30 p-3">
            <h5 className="text-xs font-semibold text-teal-300 mb-2">FDI Tooth Notation System</h5>
            <p className="text-[11px] text-white/50">{proposal.dental_standards.tooth_notation.description}</p>
            <div className="mt-2 grid grid-cols-2 gap-2">
              {Object.entries(proposal.dental_standards.tooth_notation.quadrants).map(([k, v]) => (
                <div key={k} className="text-[10px] text-white/40">
                  <span className="text-teal-400 font-mono">Q{k}</span> — {v as string}
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-lg bg-black/30 p-3">
            <h5 className="text-xs font-semibold text-teal-300 mb-2">Color Coding (Industry Standard)</h5>
            <div className="grid grid-cols-2 gap-1.5">
              {proposal.dental_standards.color_coding_reference.categories.map((cat: any) => (
                <div key={cat.condition} className="flex items-center gap-2">
                  <div className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: cat.color }} />
                  <span className="text-[10px] text-white/50">{cat.condition}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Section>

      {/* Color Schemes */}
      <Section title="Color Schemes — Professional Medical UI" icon={Palette}>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          {proposal.architecture.modules.map((mod: any) => (
            <div key={mod.id} className="rounded-lg bg-black/30 p-3">
              <h5 className="text-xs font-semibold text-white/70 mb-2">{mod.name}</h5>
              <div className="grid grid-cols-3 gap-1.5">
                {Object.entries(mod.color_scheme as Record<string, string>)
                  .filter(([, v]) => typeof v === 'string' && v.startsWith('#'))
                  .map(([key, color]) => (
                    <div key={key} className="flex items-center gap-1.5">
                      <div className="h-3 w-3 rounded" style={{ backgroundColor: color as string }} />
                      <span className="text-[9px] text-white/40">{key}</span>
                    </div>
                  ))}
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* Technology Stack */}
      <Section title="Technology Stack" icon={Cpu}>
        <div className="mt-3 space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <div className="rounded-lg bg-black/30 p-3">
              <h5 className="text-xs font-semibold text-blue-300 mb-1">Frontend</h5>
              <p className="text-[11px] text-white/50">{proposal.technology_stack.frontend.framework}</p>
              <p className="text-[10px] text-white/30">{proposal.technology_stack.frontend.build_tool} + {proposal.technology_stack.frontend.styling}</p>
            </div>
            <div className="rounded-lg bg-black/30 p-3">
              <h5 className="text-xs font-semibold text-purple-300 mb-1">AI Engine</h5>
              <p className="text-[11px] text-white/50">{proposal.technology_stack.ai_integration.primary.provider}</p>
              <p className="text-[10px] text-white/30">{proposal.technology_stack.ai_integration.primary.model}</p>
            </div>
          </div>
          <div className="rounded-lg bg-black/30 p-3">
            <h5 className="text-xs font-semibold text-cyan-300 mb-2">AI Capabilities</h5>
            <div className="flex flex-wrap gap-1.5">
              {proposal.technology_stack.ai_integration.primary.capabilities.map((c: string) => (
                <span key={c} className="inline-flex rounded-full bg-cyan-500/10 px-2 py-0.5 text-[10px] text-cyan-300">
                  {c}
                </span>
              ))}
            </div>
          </div>
        </div>
      </Section>

      {/* Mobile & Google Play */}
      <Section title="Mobile & Google Play Ready" icon={Smartphone}>
        <div className="mt-3 space-y-2">
          <p className="text-xs text-white/50">
            <span className="text-green-300 font-medium">Approach:</span> {proposal.technology_stack.mobile_ready.approach}
          </p>
          <ul className="space-y-1">
            {proposal.technology_stack.mobile_ready.google_play.requirements.map((r: string, i: number) => (
              <li key={i} className="text-[11px] text-white/40 flex items-start gap-1.5">
                <span className="text-green-400">✓</span> {r}
              </li>
            ))}
          </ul>
        </div>
      </Section>

      {/* Deployment */}
      <Section title="Free Deployment Options (MVP)" icon={Cloud}>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {proposal.technology_stack.deployment_options.free_mvp.map((d: any) => (
            <div key={d.platform} className="rounded-lg border border-white/5 bg-black/30 p-3 flex items-start gap-3">
              <div className="h-8 w-8 rounded-lg bg-white/5 flex items-center justify-center flex-shrink-0">
                <Cloud className="h-4 w-4 text-blue-400" />
              </div>
              <div>
                <h6 className="text-xs font-semibold text-white/70">{d.platform}</h6>
                <p className="text-[10px] text-white/30">{d.tier}</p>
                <p className="text-[10px] text-white/20">{d.limits}</p>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* Roadmap */}
      <Section title="Development Roadmap" icon={Calendar}>
        <div className="mt-3 space-y-3">
          {Object.entries(proposal.roadmap).map(([key, phase]: [string, any]) => (
            <div key={key} className="rounded-lg border border-white/5 bg-black/30 p-3">
              <div className="flex items-center justify-between mb-2">
                <h5 className="text-xs font-semibold text-white/70 capitalize">
                  {key.replace(/_/g, ' ')}
                </h5>
                <span className="text-[10px] text-blue-300/60">{phase.timeline}</span>
              </div>
              <ul className="space-y-1">
                {phase.deliverables.map((d: string, i: number) => (
                  <li key={i} className="text-[11px] text-white/40 flex items-start gap-1.5">
                    <GitBranch className="h-3 w-3 text-blue-400/40 flex-shrink-0 mt-0.5" />
                    {d}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </Section>

      {/* Gemini Integration */}
      <Section title="Gemini API Integration Detail" icon={Cpu}>
        <div className="mt-3 space-y-2">
          <div className="rounded-lg bg-black/30 p-3">
            <h5 className="text-xs font-semibold text-purple-300 mb-1">API Endpoint</h5>
            <code className="text-[10px] text-white/40 break-all">{proposal.gemini_integration_detail.api_endpoint}</code>
          </div>
          <div className="rounded-lg bg-black/30 p-3">
            <h5 className="text-xs font-semibold text-purple-300 mb-2">Response Schema (Dental)</h5>
            <pre className="text-[9px] text-white/30 overflow-x-auto">
              {JSON.stringify(proposal.gemini_integration_detail.response_schema.dental, null, 2)}
            </pre>
          </div>
        </div>
      </Section>

      {/* Compliance */}
      <div className="rounded-xl border border-amber-500/10 bg-amber-500/5 p-4 space-y-2">
        <h3 className="text-xs font-semibold text-amber-300 flex items-center gap-2">
          <Shield className="h-4 w-4" />
          Compliance & Legal Notes
        </h3>
        <p className="text-[11px] text-amber-300/50">{proposal.compliance_notes.disclaimer}</p>
        <p className="text-[11px] text-amber-300/40">{proposal.compliance_notes.data_privacy}</p>
        <p className="text-[11px] text-amber-300/40">{proposal.compliance_notes.medical_device_regulation}</p>
      </div>

      {/* Download JSON */}
      <a
        href="/project-proposal.json"
        download="mediclear-proposal.json"
        className="flex items-center justify-center gap-2 rounded-xl border border-blue-500/30 bg-blue-500/10 py-3 text-sm font-medium text-blue-300 hover:bg-blue-500/20 transition-colors"
      >
        <FileJson className="h-4 w-4" />
        Download Full Proposal (JSON)
      </a>
    </motion.div>
  );
}
