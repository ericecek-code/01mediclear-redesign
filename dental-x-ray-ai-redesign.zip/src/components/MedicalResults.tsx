import { motion } from 'framer-motion';
import { AlertTriangle, CheckCircle, FileText, Activity } from 'lucide-react';
import type { MedicalAnalysisResult } from '../types';

interface MedicalResultsProps {
  result: MedicalAnalysisResult;
}

export default function MedicalResults({ result }: MedicalResultsProps) {
  const hasAbnormalities = result.abnormalities.length > 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      {/* Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        <div className="rounded-xl border border-blue-500/20 bg-blue-500/5 p-3">
          <p className="text-[10px] text-blue-300/60 uppercase tracking-wider">Image Type</p>
          <p className="text-lg font-bold text-blue-300 mt-1 capitalize">{result.image_type}</p>
        </div>
        <div className={`rounded-xl border p-3 ${
          result.quality === 'good' ? 'border-green-500/20 bg-green-500/5' :
          result.quality === 'acceptable' ? 'border-yellow-500/20 bg-yellow-500/5' :
          'border-red-500/20 bg-red-500/5'
        }`}>
          <p className="text-[10px] text-white/40 uppercase tracking-wider">Quality</p>
          <p className={`text-lg font-bold mt-1 capitalize ${
            result.quality === 'good' ? 'text-green-300' :
            result.quality === 'acceptable' ? 'text-yellow-300' :
            'text-red-300'
          }`}>{result.quality}</p>
        </div>
        <div className={`rounded-xl border p-3 ${
          hasAbnormalities ? 'border-amber-500/20 bg-amber-500/5' : 'border-green-500/20 bg-green-500/5'
        }`}>
          <p className="text-[10px] text-white/40 uppercase tracking-wider">Findings</p>
          <p className={`text-lg font-bold mt-1 ${
            hasAbnormalities ? 'text-amber-300' : 'text-green-300'
          }`}>{result.abnormalities.length}</p>
        </div>
      </div>

      {/* Anatomical Structures */}
      {result.anatomical_structures.length > 0 && (
        <div className="rounded-xl border border-white/10 bg-white/5 p-4">
          <h3 className="text-sm font-semibold text-white/80 flex items-center gap-2 mb-3">
            <Activity className="h-4 w-4 text-blue-400" />
            Anatomical Structures Identified
          </h3>
          <div className="flex flex-wrap gap-2">
            {result.anatomical_structures.map((s, i) => (
              <span
                key={i}
                className="inline-flex items-center rounded-full bg-blue-500/10 px-3 py-1 text-xs text-blue-300"
              >
                {s}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Abnormalities */}
      {hasAbnormalities && (
        <div className="space-y-2">
          <h3 className="text-sm font-semibold text-white/80 flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-400" />
            Abnormalities Detected
          </h3>
          <div className="space-y-2">
            {result.abnormalities.map((a, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                className="rounded-xl border border-white/10 bg-white/5 p-3"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`h-3 w-3 rounded-full flex-shrink-0 ${
                      a.severity === 'severe' ? 'bg-red-400' :
                      a.severity === 'moderate' ? 'bg-amber-400' :
                      'bg-yellow-400'
                    }`} />
                    <span className="text-sm font-medium text-white/80">{a.type}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                      a.severity === 'severe' ? 'bg-red-500/20 text-red-300' :
                      a.severity === 'moderate' ? 'bg-amber-500/20 text-amber-300' :
                      'bg-yellow-500/20 text-yellow-300'
                    }`}>
                      {a.severity}
                    </span>
                    <span className="text-[10px] text-white/30">
                      {Math.round(a.confidence * 100)}%
                    </span>
                  </div>
                </div>
                <p className="mt-1 text-xs text-white/50">📍 {a.location}</p>
                <p className="mt-1 text-xs text-white/40">{a.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {!hasAbnormalities && (
        <div className="rounded-xl border border-green-500/20 bg-green-500/5 p-4 text-center">
          <CheckCircle className="h-8 w-8 text-green-400 mx-auto mb-2" />
          <p className="text-sm font-medium text-green-300">No significant abnormalities detected</p>
          <p className="text-xs text-green-300/50 mt-1">The X-ray appears within normal limits</p>
        </div>
      )}

      {/* Overall Assessment */}
      <div className="rounded-xl border border-blue-500/20 bg-blue-500/5 p-4">
        <h3 className="text-sm font-semibold text-blue-300 flex items-center gap-2 mb-2">
          <FileText className="h-4 w-4" />
          Overall Assessment
        </h3>
        <p className="text-sm text-white/70 leading-relaxed">{result.overall_assessment}</p>
      </div>

      {/* Recommendations */}
      {result.recommendations.length > 0 && (
        <div className="rounded-xl border border-white/10 bg-white/5 p-4">
          <h3 className="text-sm font-semibold text-white/80 mb-2">Recommendations</h3>
          <ul className="space-y-1">
            {result.recommendations.map((r, i) => (
              <li key={i} className="flex items-start gap-2 text-xs text-white/60">
                <span className="text-blue-400 mt-0.5">→</span>
                {r}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Disclaimer */}
      <div className="rounded-lg border border-amber-500/10 bg-amber-500/5 p-3">
        <p className="text-[10px] text-amber-300/60 leading-relaxed">
          ⚠️ <strong>Disclaimer:</strong> This AI analysis is for informational purposes only and is not a medical diagnosis.
          All findings must be verified by a qualified medical professional. MediClear AI is a diagnostic support tool, not a replacement for professional clinical judgment.
        </p>
      </div>
    </motion.div>
  );
}
