import { useState, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FileJson,
  Sparkles,
  Info,
} from 'lucide-react';
import Header from './components/Header';
import ApiKeyInput from './components/ApiKeyInput';
import ImageUpload from './components/ImageUpload';
import DentalChart from './components/DentalChart';
import DentalResults from './components/DentalResults';
import MedicalResults from './components/MedicalResults';
import ProposalView from './components/ProposalView';
import { analyzeImage, fileToBase64 } from './services/geminiService';
import type { AppMode, DentalAnalysisResult, MedicalAnalysisResult } from './types';

type ActiveTab = 'analyze' | 'proposal' | 'about';

export default function App() {
  const [mode, setMode] = useState<AppMode>('dental');
  const [activeTab, setActiveTab] = useState<ActiveTab>('analyze');
  const [apiKey, setApiKey] = useState(() => localStorage.getItem('gemini_api_key') || '');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [dentalResult, setDentalResult] = useState<DentalAnalysisResult | null>(null);
  const [medicalResult, setMedicalResult] = useState<MedicalAnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selectedTooth, setSelectedTooth] = useState<number | null>(null);
  const [proposal, setProposal] = useState<any>(null);

  // Persist API key
  useEffect(() => {
    if (apiKey) {
      localStorage.setItem('gemini_api_key', apiKey);
    }
  }, [apiKey]);

  // Load proposal JSON
  useEffect(() => {
    fetch('/project-proposal.json')
      .then(res => res.json())
      .then(data => setProposal(data))
      .catch(() => {});
  }, []);

  const handleImageSelect = useCallback((file: File) => {
    setImageFile(file);
    setError(null);
    setDentalResult(null);
    setMedicalResult(null);
    setSelectedTooth(null);
    const reader = new FileReader();
    reader.onload = (e) => setImagePreview(e.target?.result as string);
    reader.readAsDataURL(file);
  }, []);

  const handleClear = useCallback(() => {
    setImagePreview(null);
    setImageFile(null);
    setDentalResult(null);
    setMedicalResult(null);
    setError(null);
    setSelectedTooth(null);
  }, []);

  const handleAnalyze = useCallback(async () => {
    if (!imageFile || !apiKey) return;

    setIsAnalyzing(true);
    setError(null);

    try {
      const base64 = await fileToBase64(imageFile);
      const result = await analyzeImage(apiKey, base64, imageFile.type, mode);

      if (mode === 'dental') {
        setDentalResult(result);
        setMedicalResult(null);
      } else {
        setMedicalResult(result);
        setDentalResult(null);
      }
    } catch (err: any) {
      setError(err.message || 'Analysis failed. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  }, [imageFile, apiKey, mode]);

  const handleModeChange = useCallback((newMode: AppMode) => {
    setMode(newMode);
    setDentalResult(null);
    setMedicalResult(null);
    setError(null);
    setSelectedTooth(null);
  }, []);

  const isDental = mode === 'dental';

  return (
    <div className={`min-h-screen transition-colors duration-700 ${
      isDental
        ? 'bg-gradient-to-br from-[#021a19] via-[#042f2e] to-[#0a3d3c]'
        : 'bg-gradient-to-br from-[#0a0f1e] via-[#0f172a] to-[#1a1f3a]'
    }`}>
      {/* Background Pattern */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.03]"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, white 1px, transparent 0)`,
          backgroundSize: '40px 40px',
        }}
      />

      <Header mode={mode} onModeChange={handleModeChange} />

      {/* Tab Navigation */}
      <div className="sticky top-0 z-20 border-b border-white/5 bg-black/20 backdrop-blur-xl">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="flex gap-1">
            {([
              { id: 'analyze' as const, label: 'AI Analysis', icon: Sparkles },
              { id: 'proposal' as const, label: 'Project Proposal', icon: FileJson },
              { id: 'about' as const, label: 'About', icon: Info },
            ]).map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`relative flex items-center gap-1.5 px-4 py-3 text-xs font-medium transition-colors ${
                  activeTab === tab.id
                    ? 'text-white'
                    : 'text-white/40 hover:text-white/60'
                }`}
              >
                <tab.icon className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">{tab.label}</span>
                {activeTab === tab.id && (
                  <motion.div
                    layoutId="activeTab"
                    className={`absolute bottom-0 left-0 right-0 h-0.5 ${
                      isDental ? 'bg-teal-400' : 'bg-blue-400'
                    }`}
                    transition={{ type: 'spring', stiffness: 500, damping: 35 }}
                  />
                )}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="relative mx-auto max-w-7xl px-4 py-6 sm:px-6">
        <AnimatePresence mode="wait">
          {activeTab === 'analyze' && (
            <motion.div
              key="analyze"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              {/* API Key */}
              <ApiKeyInput apiKey={apiKey} onApiKeyChange={setApiKey} />

              {/* Main Layout */}
              <div className="grid gap-6 lg:grid-cols-2">
                {/* Left Column — Upload & Image */}
                <div className="space-y-6">
                  <ImageUpload
                    mode={mode}
                    imagePreview={imagePreview}
                    isAnalyzing={isAnalyzing}
                    onImageSelect={handleImageSelect}
                    onClear={handleClear}
                    onAnalyze={handleAnalyze}
                    hasApiKey={!!apiKey}
                  />

                  {/* Dental Chart */}
                  {isDental && dentalResult && (
                    <DentalChart
                      findings={dentalResult.teeth_identified}
                      selectedTooth={selectedTooth}
                      onSelectTooth={setSelectedTooth}
                    />
                  )}
                </div>

                {/* Right Column — Results */}
                <div className="space-y-4">
                  {error && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="rounded-xl border border-red-500/20 bg-red-500/10 p-4"
                    >
                      <p className="text-sm text-red-300">❌ {error}</p>
                    </motion.div>
                  )}

                  {isDental && dentalResult && <DentalResults result={dentalResult} />}
                  {!isDental && medicalResult && <MedicalResults result={medicalResult} />}

                  {!dentalResult && !medicalResult && !error && (
                    <div className="flex flex-col items-center justify-center rounded-2xl border border-white/5 bg-white/[0.02] p-12 text-center">
                      <div className={`mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-2xl ${
                        isDental ? 'bg-teal-500/5' : 'bg-blue-500/5'
                      }`}>
                        <Sparkles className={`h-10 w-10 ${isDental ? 'text-teal-500/30' : 'text-blue-500/30'}`} />
                      </div>
                      <h3 className="text-sm font-medium text-white/40">
                        {isDental ? 'Dental' : 'Medical'} Analysis Results
                      </h3>
                      <p className="mt-2 text-xs text-white/20 max-w-xs">
                        Upload an X-ray image and click "Analyze" to get AI-powered diagnostic insights using Google Gemini.
                      </p>
                      <div className="mt-6 grid grid-cols-2 gap-3 text-left">
                        {isDental ? (
                          <>
                            <Feature label="FDI tooth identification" />
                            <Feature label="Caries detection" />
                            <Feature label="Periapical lesions" />
                            <Feature label="Bone loss analysis" />
                            <Feature label="Restoration mapping" />
                            <Feature label="Color-coded report" />
                          </>
                        ) : (
                          <>
                            <Feature label="Structure identification" />
                            <Feature label="Abnormality detection" />
                            <Feature label="Severity scoring" />
                            <Feature label="Quality assessment" />
                            <Feature label="Clinical report" />
                            <Feature label="AI recommendations" />
                          </>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'proposal' && proposal && (
            <motion.div
              key="proposal"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
            >
              <ProposalView proposal={proposal} />
            </motion.div>
          )}

          {activeTab === 'about' && (
            <motion.div
              key="about"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="max-w-2xl mx-auto space-y-6"
            >
              <div className="text-center space-y-4 py-8">
                <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-teal-500 shadow-2xl">
                  <Sparkles className="h-10 w-10 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-white">
                  Medi<span className="text-teal-400">Clear</span> AI
                </h2>
                <p className="text-sm text-white/50 max-w-lg mx-auto leading-relaxed">
                  AI-powered dental and medical X-ray analysis platform built with cutting-edge technology.
                  Designed to support healthcare professionals with intelligent diagnostic insights.
                </p>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <InfoCard
                  title="Dual-Mode Analysis"
                  description="Switch between dental and medical X-ray analysis modes. Each mode uses specialized AI prompts optimized for the specific imaging type."
                  color="blue"
                />
                <InfoCard
                  title="FDI Standard Compliance"
                  description="Dental module uses the FDI two-digit notation system (ISO 3950) — the international standard for tooth identification used by dentists worldwide."
                  color="teal"
                />
                <InfoCard
                  title="Google Gemini AI"
                  description="Powered by Gemini 2.5 Flash vision model for state-of-the-art image understanding with structured JSON output for precise diagnostic reports."
                  color="purple"
                />
                <InfoCard
                  title="Mobile & PWA Ready"
                  description="Designed for deployment as a Progressive Web App, compatible with Capacitor.js for Google Play Store distribution."
                  color="green"
                />
              </div>

              <div className="rounded-xl border border-white/10 bg-white/5 p-6 space-y-4">
                <h3 className="text-sm font-semibold text-white/80">Technology Stack</h3>
                <div className="flex flex-wrap gap-2">
                  {['React 19', 'TypeScript', 'Vite 7', 'Tailwind CSS 4', 'Framer Motion',
                    'Gemini AI', 'Lucide Icons', 'PWA Ready'].map(tech => (
                    <span key={tech} className="rounded-full bg-white/5 border border-white/10 px-3 py-1 text-xs text-white/60">
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-center gap-4 pt-4">
                <a
                  href="https://github.com/ericecek-code/01mediclear"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-4 py-2 text-xs text-white/60 hover:bg-white/10 transition-colors"
                >
                  <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"/></svg>
                  GitHub Repository
                </a>
                <a
                  href="https://aistudio.google.com/apikey"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 rounded-lg border border-blue-500/30 bg-blue-500/10 px-4 py-2 text-xs text-blue-300 hover:bg-blue-500/20 transition-colors"
                >
                  <Sparkles className="h-4 w-4" />
                  Get Gemini API Key
                </a>
              </div>

              <div className="rounded-lg border border-amber-500/10 bg-amber-500/5 p-4 text-center">
                <p className="text-[11px] text-amber-300/60 leading-relaxed">
                  ⚠️ MediClear AI is a diagnostic <strong>support tool</strong> — not a medical device.
                  All AI outputs must be verified by qualified healthcare professionals.
                  Not certified under EU MDR or FDA regulations.
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 mt-12">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 flex items-center justify-between">
          <p className="text-[10px] text-white/20">
            © 2025 MediClear AI • Diagnostic Support Tool
          </p>
          <p className="text-[10px] text-white/20">
            Powered by Google Gemini
          </p>
        </div>
      </footer>
    </div>
  );
}

function Feature({ label }: { label: string }) {
  return (
    <div className="flex items-center gap-2 text-[11px] text-white/30">
      <div className="h-1 w-1 rounded-full bg-white/20" />
      {label}
    </div>
  );
}

function InfoCard({ title, description, color }: { title: string; description: string; color: string }) {
  const colorClasses: Record<string, string> = {
    blue: 'border-blue-500/20 bg-blue-500/5',
    teal: 'border-teal-500/20 bg-teal-500/5',
    purple: 'border-purple-500/20 bg-purple-500/5',
    green: 'border-green-500/20 bg-green-500/5',
  };
  const titleColors: Record<string, string> = {
    blue: 'text-blue-300',
    teal: 'text-teal-300',
    purple: 'text-purple-300',
    green: 'text-green-300',
  };

  return (
    <div className={`rounded-xl border p-4 ${colorClasses[color]}`}>
      <h4 className={`text-sm font-semibold ${titleColors[color]}`}>{title}</h4>
      <p className="mt-2 text-xs text-white/40 leading-relaxed">{description}</p>
    </div>
  );
}
