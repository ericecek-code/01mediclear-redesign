export type AppMode = 'medical' | 'dental';

export interface ToothFinding {
  fdi_number: number;
  status: 'healthy' | 'caries' | 'restored' | 'missing' | 'impacted' | 'root_canal' | 'crown' | 'implant';
  findings: string[];
  confidence: number;
}

export interface Pathology {
  type: string;
  location: string;
  severity: 'mild' | 'moderate' | 'severe';
  description: string;
  confidence: number;
  color: string;
}

export interface DentalAnalysisResult {
  image_type: string;
  quality: string;
  teeth_identified: ToothFinding[];
  pathologies: Pathology[];
  overall_assessment: string;
  recommendations: string[];
}

export interface MedicalAnalysisResult {
  image_type: string;
  quality: string;
  anatomical_structures: string[];
  abnormalities: {
    type: string;
    location: string;
    severity: string;
    description: string;
    confidence: number;
  }[];
  overall_assessment: string;
  recommendations: string[];
}

export interface AnalysisState {
  isAnalyzing: boolean;
  imagePreview: string | null;
  imageFile: File | null;
  dentalResult: DentalAnalysisResult | null;
  medicalResult: MedicalAnalysisResult | null;
  error: string | null;
}

export const DENTAL_CONDITION_COLORS: Record<string, string> = {
  caries: '#FF6B6B',
  periapical: '#FF4757',
  bone_loss: '#FCE38A',
  restoration: '#4ECDC4',
  crown: '#DDA0DD',
  root_canal: '#F38181',
  implant: '#95E1D3',
  impacted: '#E17055',
  calculus: '#FFEAA7',
  healthy: '#2ED573',
  missing: '#94A3B8',
};

export const FDI_TEETH = {
  upper_right: [18, 17, 16, 15, 14, 13, 12, 11],
  upper_left: [21, 22, 23, 24, 25, 26, 27, 28],
  lower_left: [31, 32, 33, 34, 35, 36, 37, 38],
  lower_right: [48, 47, 46, 45, 44, 43, 42, 41],
};

export const TOOTH_NAMES: Record<number, string> = {
  11: 'Central Incisor', 12: 'Lateral Incisor', 13: 'Canine',
  14: '1st Premolar', 15: '2nd Premolar', 16: '1st Molar',
  17: '2nd Molar', 18: '3rd Molar (Wisdom)',
  21: 'Central Incisor', 22: 'Lateral Incisor', 23: 'Canine',
  24: '1st Premolar', 25: '2nd Premolar', 26: '1st Molar',
  27: '2nd Molar', 28: '3rd Molar (Wisdom)',
  31: 'Central Incisor', 32: 'Lateral Incisor', 33: 'Canine',
  34: '1st Premolar', 35: '2nd Premolar', 36: '1st Molar',
  37: '2nd Molar', 38: '3rd Molar (Wisdom)',
  41: 'Central Incisor', 42: 'Lateral Incisor', 43: 'Canine',
  44: '1st Premolar', 45: '2nd Premolar', 46: '1st Molar',
  47: '2nd Molar', 48: '3rd Molar (Wisdom)',
};
