const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';

const DENTAL_PROMPT = `You are a dental radiology AI assistant specialized in analyzing dental X-ray images. 
Analyze the provided dental X-ray image thoroughly and respond ONLY in valid JSON format with this exact structure:

{
  "image_type": "OPG/periapical/bitewing/other",
  "quality": "good/acceptable/poor",
  "teeth_identified": [
    {
      "fdi_number": 11,
      "status": "healthy/caries/restored/missing/impacted/root_canal/crown/implant",
      "findings": ["description of finding"],
      "confidence": 0.85
    }
  ],
  "pathologies": [
    {
      "type": "caries/periapical/bone_loss/calculus/impacted/fracture",
      "location": "tooth number or region",
      "severity": "mild/moderate/severe",
      "description": "detailed description",
      "confidence": 0.8
    }
  ],
  "overall_assessment": "Summary of dental health status",
  "recommendations": ["recommendation 1", "recommendation 2"]
}

Use FDI notation (two-digit system: quadrant 1-4 + tooth position 1-8).
Be thorough but conservative in your findings. Include confidence scores.
IMPORTANT: Return ONLY the JSON, no markdown formatting, no code blocks.`;

const MEDICAL_PROMPT = `You are a medical radiology AI assistant specialized in analyzing medical X-ray images.
Analyze the provided medical X-ray image thoroughly and respond ONLY in valid JSON format with this exact structure:

{
  "image_type": "chest/bone/abdomen/skull/spine/other",
  "quality": "good/acceptable/poor",
  "anatomical_structures": ["structure 1", "structure 2"],
  "abnormalities": [
    {
      "type": "type of abnormality",
      "location": "anatomical location",
      "severity": "mild/moderate/severe",
      "description": "detailed description",
      "confidence": 0.8
    }
  ],
  "overall_assessment": "Summary of findings",
  "recommendations": ["recommendation 1", "recommendation 2"]
}

Be thorough but conservative in your findings. Include confidence scores.
IMPORTANT: Return ONLY the JSON, no markdown formatting, no code blocks.`;

export async function analyzeImage(
  apiKey: string,
  imageBase64: string,
  mimeType: string,
  mode: 'dental' | 'medical'
): Promise<any> {
  const prompt = mode === 'dental' ? DENTAL_PROMPT : MEDICAL_PROMPT;

  const response = await fetch(`${GEMINI_API_URL}?key=${apiKey}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      contents: [
        {
          parts: [
            { text: prompt },
            {
              inline_data: {
                mime_type: mimeType,
                data: imageBase64,
              },
            },
          ],
        },
      ],
      generationConfig: {
        temperature: 0.2,
        topP: 0.8,
        maxOutputTokens: 4096,
      },
    }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => null);
    throw new Error(
      errorData?.error?.message || `API Error: ${response.status} ${response.statusText}`
    );
  }

  const data = await response.json();
  const textContent = data.candidates?.[0]?.content?.parts?.[0]?.text;

  if (!textContent) {
    throw new Error('No response received from Gemini API');
  }

  // Clean the response - remove markdown code blocks if present
  let cleanedText = textContent.trim();
  if (cleanedText.startsWith('```json')) {
    cleanedText = cleanedText.slice(7);
  } else if (cleanedText.startsWith('```')) {
    cleanedText = cleanedText.slice(3);
  }
  if (cleanedText.endsWith('```')) {
    cleanedText = cleanedText.slice(0, -3);
  }
  cleanedText = cleanedText.trim();

  try {
    return JSON.parse(cleanedText);
  } catch {
    throw new Error('Failed to parse AI response. Raw response: ' + textContent.substring(0, 200));
  }
}

export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Remove the data URL prefix to get just the base64
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
